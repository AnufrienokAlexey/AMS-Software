<?php

return [
    'host' => 'localhost',
    'dbname' => 'ipalexan_amssoft',
    'charset' => 'utf8',
    'username' => 'ipalexan_amssoft',
    'password' => 'eOGXn*%R3CnN',
];
