<?php

namespace app\core;

class Model
{

}
