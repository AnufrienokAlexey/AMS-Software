<div class="flex center-container">
    <h1>Ошибка 404. Такой страницы не существует.</h1>
    <img src="/app/public/images/404.jpeg" alt="404">
</div>
